
import numpy as np
import matplotlib.pyplot as plt

# Definir la función que queremos derivar
def f(x):
    return x**2 + 2*x + 1  # Puedes cambiar esta función

# Definir la derivada con la definición del límite
def derivada_limite(f, x0, h=1e-5):
    return (f(x0 + h) - f(x0)) / h

# Punto donde queremos calcular la derivada
x0 = 1.0

# Calcular el valor de la derivada en x0
f_prime = derivada_limite(f, x0)
print(f"Derivada de f(x) en x = {x0} es aproximadamente: {f_prime:.4f}")

# Crear la recta tangente
def recta_tangente(x):
    return f_prime * (x - x0) + f(x0)

# Crear valores de x para graficar
x_vals = np.linspace(x0 - 5, x0 + 5, 400)
y_vals = f(x_vals)
tangent_vals = recta_tangente(x_vals)

# Graficar la función y la recta tangente
plt.figure(figsize=(10, 6))
plt.plot(x_vals, y_vals, label='f(x)', color='blue')
plt.plot(x_vals, tangent_vals, label='Recta tangente', linestyle='--', color='red')
plt.scatter(x0, f(x0), color='black', label=f'Punto de tangencia ({x0}, {f(x0):.2f})')
plt.title('Derivada por definición de límite con gráfica')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
plt.axvline(x0, linestyle=':', color='gray')
plt.savefig('grafica.png')
