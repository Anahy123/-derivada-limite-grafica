
# Derivada por Límite con Gráfica 📈

Este proyecto en Python muestra cómo calcular la derivada de una función usando la **definición de derivada como límite** y grafica:

- La función original `f(x)`
- La **recta tangente** en un punto específico

---

## 📌 Ejemplo de función utilizada

```python
f(x) = x² + 2x + 1
```

La derivada en `x = 1` se calcula con:

```
f'(x) ≈ (f(x + h) - f(x)) / h
```

---

## ▶️ Cómo ejecutar

1. Clona este repositorio o descarga los archivos.
2. Asegúrate de tener Python 3 instalado.
3. Instala las librerías necesarias:

```bash
pip install numpy matplotlib
```

4. Ejecuta el archivo:

```bash
python derivada_limite_grafica.py
```

---

## ✏️ Puedes modificar

- La función en `def f(x)`
- El punto de derivación `x0`
- El valor de `h` (diferencia infinitesimal)

---

## 🧠 Ideal para

- Estudiantes de cálculo diferencial
- Proyectos de aprendizaje de Python matemático
- Visualizaciones educativas

---

## 📷 Gráfica

Se genera automáticamente al ejecutar el script y se guarda como `grafica.png`.

---

## 📜 Licencia

Este proyecto es de uso libre para fines educativos.
